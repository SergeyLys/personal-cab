export type Processor = ( spec : ComponentDefinition, baseProto : Object ) => ComponentDefinition;

export interface ComponentDefinition {
    
}