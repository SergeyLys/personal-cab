import { Link } from './link'
export default Link;
export * from './component'
export * from './link'