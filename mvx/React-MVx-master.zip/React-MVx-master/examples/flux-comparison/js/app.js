import React from 'nestedreact'
import App from './components/App.jsx'

React.render(
    React.createElement( App, null ),
    document.getElementById( 'non-flux-app' )
);
