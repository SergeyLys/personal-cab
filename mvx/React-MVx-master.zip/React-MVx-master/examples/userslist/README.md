# UsersList Example

Here's the UsersList application example, written originally for NestedLink.

It's changed to use NestedReact. Feel the difference.

NestedLink data binding is so powerful that there are no any difference
in size, so expressiveness is roughly the same.

But. Check out how much less magical NestedReact solution feels - compare the code.

In fact, there's an incredible amount of dirty magic involved,
just to make you feel that there are no any magic at all :).

That's NestedReact. Relax, and write in natural way, no tricks are required.
