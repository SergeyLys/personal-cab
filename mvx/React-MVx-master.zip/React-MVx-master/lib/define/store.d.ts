export default function process(spec: any, baseProto: any): void;
