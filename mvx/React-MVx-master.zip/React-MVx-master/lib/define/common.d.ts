export default function compile(spec: any, {_autobind}: {
    _autobind?: undefined[];
}): void;
export declare function asyncUpdate(): void;
