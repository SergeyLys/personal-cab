export default function process(spec: any, baseProto?: {}): any;
export { Node, Element, TypeSpecs } from './typeSpecs';
