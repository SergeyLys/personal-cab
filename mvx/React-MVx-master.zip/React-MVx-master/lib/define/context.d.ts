export default function process(spec: any, {_context, _childContext}: {
    _context?: {};
    _childContext?: {};
}): void;
